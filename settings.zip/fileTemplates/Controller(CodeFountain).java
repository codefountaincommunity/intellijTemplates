#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set ($index = $NAME.indexOf("Controller"))
#set ($API= $NAME.substring(0, $index))
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RestController
@RequestMapping("/${API}")
public class ${NAME} {
private static final Logger LOGGER = LoggerFactory.getLogger(${NAME}.class);

}