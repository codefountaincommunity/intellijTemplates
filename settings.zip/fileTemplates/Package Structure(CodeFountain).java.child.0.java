#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import ${PACKAGE_NAME}.services.${NAME}Service;
import ${PACKAGE_NAME}.repositories.${NAME}Repository;

@Service
public class ${NAME}ServiceImpl implements ${NAME}Service{
private static final Logger LOGGER = LoggerFactory.getLogger(${NAME}ServiceImpl.class);

    @Autowired
    private  ${NAME}Repository ${NAME.toLowerCase()}Repository;
    
}