#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ${PACKAGE_NAME}.services.${NAME}Service;
@RestController
@RequestMapping("/${NAME.toLowerCase()}")
public class ${NAME}Controller {
private static final Logger LOGGER = LoggerFactory.getLogger(${NAME}Controller.class);
    @Autowired
    private  ${NAME}Service ${NAME.toLowerCase()}Service;
}