#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import ${PACKAGE_NAME}.entities.${NAME};
import ${PACKAGE_NAME}.dto.${NAME}DTO;
import ${PACKAGE_NAME}.services.${NAME}Service;
import ${PACKAGE_NAME}.repositories.${NAME}Repository;

@Service
public class ${NAME}ServiceImpl implements ${NAME}Service{
private static final Logger LOGGER = LoggerFactory.getLogger(${NAME}ServiceImpl.class);

    @Autowired
    private  ${NAME}Repository ${NAME.toLowerCase()}Repository;
     @Override
     public ${NAME}DTO create${NAME}(${NAME}DTO ${NAME.toLowerCase()}DTO) {
      ${NAME} ${NAME.toLowerCase()} =  ${NAME.toLowerCase()}Repository.save(${NAME.toLowerCase()}DTO.mapToEntity(${NAME.toLowerCase()}DTO));
        LOGGER.info("${NAME} created");
        return ${NAME.toLowerCase()}DTO.mapToDto(${NAME.toLowerCase()});
    }
    
    @Override
    public ${NAME}DTO update${NAME}(Long id, ${NAME}DTO ${NAME.toLowerCase()}DTO) {
       ${NAME}DTO existing${NAME} = get${NAME}ById(id);

            ${NAME} ${NAME.toLowerCase()} = new ${NAME}();
            if(existing${NAME}!=null) {
                ${NAME.toLowerCase()} = existing${NAME}.mapToEntity(${NAME.toLowerCase()}DTO);
                ${NAME.toLowerCase()}Repository.save(${NAME.toLowerCase()});
               return ${NAME.toLowerCase()}DTO.mapToDto(${NAME.toLowerCase()});
            }else {
                LOGGER.info("${NAME} doesn't exist");
                return null;
            }
    }
    
     @Override
    public ${NAME}DTO get${NAME}ById(Long id) {
       Optional<${NAME}> ${NAME.toLowerCase()} = ${NAME.toLowerCase()}Repository.findById(id);
        if (${NAME.toLowerCase()}.isPresent()) {
         ${NAME}DTO ${NAME.toLowerCase()}DTO =  new ${NAME}DTO();
            return ${NAME.toLowerCase()}DTO.mapToDto(${NAME.toLowerCase()}.get());

        } else {
            LOGGER.info("${NAME} doesn't exist");
            return null;
        }
    }
     @Override
    public List<${NAME}DTO> getAll${NAME}s() {
     LOGGER.info("getAll ${NAME}s");
        List<${NAME}> listOf${NAME}s =${NAME.toLowerCase()}Repository.findAll();
        ${NAME}DTO ${NAME.toLowerCase()}DTO =  new ${NAME}DTO();
        return listOf${NAME}s.stream().map(${NAME.toLowerCase()}->${NAME.toLowerCase()}DTO.mapToDto(${NAME.toLowerCase()})).collect(Collectors.toList());
   
    }
    
     @Override
    public Page<${NAME}DTO> getAll${NAME}s(Pageable pageable) {
    Page<${NAME}> ${NAME.toLowerCase()}Pages =${NAME.toLowerCase()}Repository.findAll(pageable);
        ${NAME}DTO ${NAME.toLowerCase()}DTO =  new ${NAME}DTO();
        Page<${NAME}DTO> new${NAME}DTO=${NAME.toLowerCase()}Pages.map(${NAME.toLowerCase()}->${NAME.toLowerCase()}DTO.mapToDto(${NAME.toLowerCase()}));
        return new${NAME}DTO;
     }
     @Override
    public void delete${NAME}(Long id) {
     Optional<${NAME}> ${NAME.toLowerCase()} =${NAME.toLowerCase()}Repository.findById(id);
        LOGGER.info("delete ${NAME} Id" + id);
        if(${NAME.toLowerCase()}.isPresent())
        ${NAME.toLowerCase()}Repository.delete(${NAME.toLowerCase()}.get());
        else
            LOGGER.info("${NAME} not exist");
     }
    
      @Override
    public void deleteAll${NAME}s() {
    LOGGER.info("delete ${NAME}s");
        ${NAME.toLowerCase()}Repository.deleteAll();
    }
}