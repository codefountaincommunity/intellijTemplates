#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ${PACKAGE_NAME}.entities.${NAME};
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ${NAME}DTO {
   
    private Long id;
    

    public ${NAME} mapToEntity(${NAME}DTO ${NAME.toLowerCase()}Dto) {
        ${NAME} ${NAME.toLowerCase()} = new ${NAME}();
        ${NAME.toLowerCase()}.setId(${NAME.toLowerCase()}Dto.getId());
        return ${NAME.toLowerCase()};


    }

    public ${NAME}DTO mapToDto(${NAME} ${NAME.toLowerCase()}) {
        ${NAME}DTO ${NAME.toLowerCase()}DTO = new ${NAME}DTO();
        ${NAME.toLowerCase()}DTO.setId(${NAME.toLowerCase()}.getId());
        
        return ${NAME.toLowerCase()}DTO;

    }
    
}