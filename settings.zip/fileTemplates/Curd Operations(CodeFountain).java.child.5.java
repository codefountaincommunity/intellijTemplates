#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import ${PACKAGE_NAME}.entities.${NAME};
import ${PACKAGE_NAME}.dto.${NAME}DTO;
import java.util.List;
public interface ${NAME}Service{
  public ${NAME}DTO create${NAME}(${NAME}DTO ${NAME.toLowerCase()}DTO);
    public ${NAME}DTO update${NAME}(Long id, ${NAME}DTO ${NAME.toLowerCase()}DTO);
    public ${NAME}DTO get${NAME}ById(Long id);  
    public List<${NAME}DTO> getAll${NAME}s();
    public Page<${NAME}DTO> getAll${NAME}s(Pageable pageable);
    public void delete${NAME}(Long id);
    public void deleteAll${NAME}s(); 

}