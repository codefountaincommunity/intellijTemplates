#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ${PACKAGE_NAME}.${NAME};
@Service
public class ${NAME}Impl implements ${NAME}{
private static final Logger LOGGER = LoggerFactory.getLogger(${NAME}Impl.class);


}