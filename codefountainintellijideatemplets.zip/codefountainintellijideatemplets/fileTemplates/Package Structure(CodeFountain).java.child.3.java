#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import jakarta.persistence.Id;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ${PACKAGE_NAME}.dto.${NAME}DTO;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "${NAME.toLowerCase()}")
public class ${NAME} {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    public ${NAME} dtoToEntity(${NAME}DTO ${NAME.toLowerCase()}Dto){
   
    ${NAME} ${NAME.toLowerCase()} = new ${NAME}();
       ${NAME.toLowerCase()}.setId(${NAME.toLowerCase()}Dto.getId());
        return ${NAME.toLowerCase()};
    }
    
    
    }
 
    