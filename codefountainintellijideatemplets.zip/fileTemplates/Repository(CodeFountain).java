#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set ($index = $NAME.indexOf("Repository"))  #set ($index = $NAME.indexOf("Repo"))
#set ($ENTITY= $NAME.substring(0, $index))

import org.springframework.data.jpa.repository.JpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface ${NAME} extends JpaRepository<$ENTITY, Long> {
private static final Logger LOGGER = LoggerFactory.getLogger(${NAME}.class);
}